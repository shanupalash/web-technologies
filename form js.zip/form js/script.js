let name = document.getElementById("name");
let email